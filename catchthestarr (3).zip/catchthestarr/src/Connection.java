
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ASUS
 */
public class Connection {
     private java.sql.Connection con; 
    private String url;
    private String uname;
    private String pass;
    private String query;
    private Statement stmt;
    
     public Connection(){
        url = "jdbc:mysql://localhost/catchgame_db";
        uname = "root";
        pass = "";
        setConnectionAndStatement();
    }
    private void setConnectionAndStatement(){
        try {
            con = DriverManager.getConnection(url, uname,pass);
            stmt = con.createStatement();
        } catch (SQLException ex) {
           System.err.print(ex.getMessage());
           System.exit(1);
        }
    
     }
    
    
}
