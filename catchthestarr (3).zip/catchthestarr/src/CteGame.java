/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
  import java.awt.CardLayout;
import java.io.File;
import java.awt.CardLayout;
import java.awt.*;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JFrame;
import javax.swing.JPanel;
/**
 *
 * @author ASUS
 */
public class CteGame extends JFrame
{	
	static MenuPanel mp = new MenuPanel();
	static HelpPanel hp = new HelpPanel();
        static UsernamePanel up = new UsernamePanel();
	static GamePanel gp = new GamePanel();
        static LevelPanel lp = new LevelPanel();
	static GamePanelMedium gm = new GamePanelMedium();
        static GamePanelHard gh = new GamePanelHard();

        
	static CardLayout cl = new CardLayout();
	static JPanel cards = new JPanel();  // to contain the panels as cards
	
	CteGame()
	{
		cards.setLayout(cl);// setting the layout to cardlayout
		cards.add(mp, "MenuPanel");
		cards.add(hp, "HelpPanel");
                cards.add(up, "UsernamePanel");
                cards.add(lp, "LevelPanel");
		cards.add(gp, "GamePanel");
                cards.add(gm, "GamePanelMedium");
                cards.add(gh, "GamePanelHard");
                
         
                
		cl.show(cards, "MenuPanel");
		add(cards); //adding the panel with cardlayout in JFrame
		
		mainSound() ;
		
		setTitle("Catch The Stars Game");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1024, 730); //frame size
		setVisible(true);   //frame visibility	
	}//end constructor
	
	void mainSound()
	{
		try
		{
			File sound = new File("sound//chick.wav");
		    AudioInputStream ais = AudioSystem.getAudioInputStream(sound);
		    Clip clip = AudioSystem.getClip();
		    clip.open(ais);
		    clip.loop(Clip.LOOP_CONTINUOUSLY);
		    clip.start();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	public static void main(String [] args)
	{
		new CteGame(); //making an object
		
	}//end main

    static class cl {

        public cl() {
        }
    }
}//end class

