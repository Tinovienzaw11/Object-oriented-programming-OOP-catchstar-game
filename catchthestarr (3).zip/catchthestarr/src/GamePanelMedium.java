/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Shape;
import java.util.Random;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;


class GamePanelMedium extends JPanel
{ 
	
	Image gamebkg     = new ImageIcon("src/image/gamebkg.png").getImage();
	Image ufo         = new ImageIcon("src/image/ufo.png").getImage();
	Image star        = new ImageIcon("src/image/star.png").getImage();
	Image gameOverbkg = new ImageIcon("src/image/gameOverbkg.png").getImage();
	Image tempbkg; //temporary background
	
	JButton restart = new JButton("");
	JButton exit = new JButton("");
	
	int x_ufo,y_ufo; //ufo x and y  coordinates
	int x_star,y_star; // x and y coord of star
	int x_Star , y_Star ;
	Random rand = new Random(); // for randomizing xcoord of stars
	
	/*JLabel time;*/
	JLabel points;
        JLabel life;
	JPanel res = new JPanel();
	
	int pointsCount = 0;
        /*int timeleft = 59;*/
	int counter  = 0;
        int lifeCount = 3;
       
        float ufoSpeed=2f;
	
        boolean gameOver = false;
        private ActionListener al;
        private Ufo Ufo;
        	
	GamePanelMedium()
	{
		setLayout(null);
		setFocusable(true);
		tempbkg = gamebkg;
		
		x_ufo = 450; 
                y_ufo = 550;
		x_star = (int)rand.nextInt(1000);
		y_star = 0;
		
	    /*time = new JLabel("Time:" +timeleft);
            time.setForeground(Color.WHITE);
		time.setBounds(20, 10, 50, 20); //setting the time label on screen*/
                
	    
	    life = new JLabel("Life: 5" );
            life.setForeground(Color.WHITE);
            life.setBounds(200, 10, 100, 20);
            
	    points = new JLabel("Points: 0");
            points.setForeground(Color.WHITE);
		points.setBounds(100,10,100,20);
               
		/*adding both components in jpanel
		add(time);*/
		add(points);
                add(life);
		
		this.addKeyListener(new KeyAdapter()
		{	
                        @Override
			public void keyPressed(KeyEvent ke)
			{
				if(ke.getKeyCode() == ke.VK_LEFT & x_ufo>20)
				{
					x_ufo-=30*ufoSpeed;
					repaint(); // redraw at new position
				}
				if(ke.getKeyCode() == ke.VK_RIGHT & x_ufo<1000)
				{
					x_ufo+=30*ufoSpeed; // redraw at new position
					repaint();
                                }
                        }
                });
                
                
                this.addMouseMotionListener(new MouseMotionListener()
		{
			@Override
			public void mouseMoved(MouseEvent me) 
			{
				x_ufo = me.getX();
				if (x_ufo > 900)
				{
					x_ufo = 900;
				}             
			}	
			@Override
			public void mouseDragged(MouseEvent e)
			{
				// TODO Auto-generated method stub		
			}
		});//end mousemotion
	}//end constructor
	
//star fall was here 
	
 
        void fallStar(){
                     if(y_star>=505){
                         y_star = 0;
                         x_star = rand.nextInt(500);
                         lifeCount--;
                     }else{
                         y_star+=5;
                         
                     }
                     life.setText("Life : " +lifeCount);
                     
                     
            }
        
	void updateLife(){	
	}
	
        
       
        
	void detectCollision()
	{
		Rectangle ufoRect = new Rectangle(x_ufo,y_ufo,100,65); //making a rectangle on the ufo
		Rectangle starRect  = new Rectangle(x_star,y_star,45,67); //making a rectangle on star
		
                if(starRect.intersects(ufoRect))
                {
                    pointsCount+=5;
                    points.setText("Points: " +pointsCount);
                    y_star=0;
                    
                    x_star= rand.nextInt(900); 
                    
                } 
        }
	
	void checkGameOver()
	{
		if(lifeCount<=0)
		{				
		 JLabel yourScore = new JLabel("Your Score: " +pointsCount);
                 tempbkg = gameOverbkg;
                 yourScore.setBounds(400, 400, 200, 100);
                 gameOver = true;
                 yourScore.setForeground(Color.WHITE);
                 add(yourScore);
                 restart.setBounds(400, 550, 252,82);
                 ImageIcon restartButton = new ImageIcon("src/button/back.png");
                 restart.setIcon(restartButton);
                 add(restart);
                 restart.addMouseListener(new MouseAdapter()
                 {
                     public void mouseClicked(MouseEvent me)
                    {
                        remove(yourScore);
                        CteGame.cl.show(CteGame.cards, "MenuPanel");
                    tempbkg = gamebkg;
                    }
                 });
                 exit.setBounds(400, 470, 252,82);
                 ImageIcon exitButton = new ImageIcon("src/button/exit.png");
                 exit.setIcon(exitButton);
                 add(exit);
                 exit.addMouseListener(new MouseAdapter()
                 {
                     public void mouseClicked(MouseEvent me)
                    {
                        System.exit(0);
                    }
                 });
                }
        }

	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D)g;
		g2d.drawImage(tempbkg,0,0,null); //game background
		 
		checkGameOver();
	
		
		if(gameOver == false)
		{
			setFocusable(true);
			grabFocus();
			updateLife();
			fallStar();
			detectCollision();
		
		    g2d.drawImage(star, x_star, y_star,null); //drawing star at new position
		g2d.drawImage(ufo, x_ufo, y_ufo, null); //drawing ufo
                }
                repaint();
		    //	 g2d.drawImage(cStar, x_star, 645, null) ;
		    	
        }

   
    class Ufo {

     
        public Ufo() {
        }

        private void updateScore() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private void updateLife() {
            life.setText("Score = :"+"   Life= "+(lifeCount));
        }
    }

}//end class
