
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.util.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ASUS
 */
public class LevelPanel extends JPanel{
    
    JButton easy = new JButton("");
    JButton medium = new JButton("");
    JButton hard = new JButton("");
    JButton back = new JButton("");
    
    Image menubkg = new ImageIcon("src/image/menubkg.png").getImage();  //menu background
	
	/* Setting icons on buttons */
	ImageIcon easybtn = new ImageIcon("src/button/easy.png"); 
	ImageIcon mediumbtn = new ImageIcon("src/button/medium.png");
	ImageIcon hardbtn = new ImageIcon("src/button/hard.png");
        ImageIcon backbtn = new ImageIcon("src/button/back.png");
        
       

	JPanel center = new JPanel();
        MenuPanel mp;
        
     LevelPanel(){
         center.setLayout(new BoxLayout(center,BoxLayout.X_AXIS)); //setting box layout 
		add(center); //adding the panel to another JPanel
                
                
            this.mp = mp;
            
            easy.setIcon(easybtn);
            medium.setIcon(mediumbtn);
            hard.setIcon(hardbtn);
            back.setIcon(backbtn);
            

            
            
           this.add(easy);
           this.add(medium);
           this.add(hard);
           this.add(back);
           
           easy.setLocation(10, 40);
           medium.setLocation(10, 50);
          hard.setLocation(10, 60);
           back.setLocation(10, 70);
           
           /* adding mouseListeners on buttons */
	easy.addMouseListener(new Click());
	medium.addMouseListener(new Click());
		hard.addMouseListener(new Click());
                back.addMouseListener(new Click());
		
	}//end constructor

	class Click extends MouseAdapter{ //internal friendly class
	
		public void mouseClicked(MouseEvent me)
        {
			if(me.getSource()== easy)
			{
				CteGame.cl.show(CteGame.cards, "GamePanel"); //show gamePanel when play is clicked
			}
			if(me.getSource()== medium)
			{
				CteGame.cl.show(CteGame.cards, "GamePanelMedium"); //show helpPanel when help is clicked
			}	
                        if(me.getSource()== hard)
			{
				CteGame.cl.show(CteGame.cards, "GamePanelHard"); //show helpPanel when help is clicked
			}	
			if(me.getSource()== back)
			{
				CteGame.cl.show(CteGame.cards, "MenuPanel"); //show helpPanel when help is clicked
			}	
		}//end mouseClick
	}//end mouseAdaptersy)
        public void paintComponent(Graphics g)
	{
		super.paintComponent(g); //calling the super class functions
		Graphics2D g2d = (Graphics2D)g; //casting to graphcis2D
		setFocusable(true);		 //setting the focus on the panel
	
		g2d.drawImage(menubkg, 0,0, null); //draw menu image
		repaint();
	}//end paintComponent
}



